package org.scoula.beans;
/*
org.scoula.beans 패키지에 Person3 클래스를 정의하세요
    ○ 빈으로 자동 등록되도록 지정
    ○ name 을 " 로 지정
    ○ Parrot2 를 생성자 주입을 통해 자동 설정
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Person3 {
    private String name = "Ella";

    private final Parrot2 parrot;

    @Autowired
    public Person3(Parrot2 parrot) {
        this.parrot = parrot;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Parrot2 getParrot() {
        return parrot;
    }
}
