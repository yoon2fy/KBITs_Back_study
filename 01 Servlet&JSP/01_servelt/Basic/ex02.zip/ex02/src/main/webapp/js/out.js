
function call() {
    alert("내가 호출이 되는 군요!");
}
