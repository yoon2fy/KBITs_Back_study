package org.scoula.ex02;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "you", value = "/you")
public class YourServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("get요청 들어옴.");

        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();
        out.println("<html>");
        out.println("<head><title>브라우저로 전송되는 출력 내용</title></head>");
        out.println("<body bgcolor='yellow'>");
        out.println("<h1>서버에서 브라우저로 전송되는 내용</h1>");
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("post요청 들어옴.");
    }

    @Override
    public void destroy() {
        System.out.println("서블릿 소멸시 한번 자동 호출됨.");
        System.out.println("db close해줄 것이나..");
        System.out.println("파일 삭제해주는 것이나..");
    }

    @Override
    public void init() throws ServletException {
        System.out.println("서블릿 생성시 한번 자동 호출됨.");
        System.out.println("필드 초기화..");
    }
}

