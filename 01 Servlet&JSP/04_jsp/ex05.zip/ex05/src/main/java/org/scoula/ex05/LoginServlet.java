package org.scoula.ex05;

// imports
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/* [LoginServlet]
(1) url 맵핑: /login
(2) userid, passwd 파라미터를 추출하여 request 스코프에 저장
(3) login.jsp로 포워딩
 */

@WebServlet("/login") // (1) url 맵핑: /login
public class LoginServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // (2) userid, passwd 파라미터를 추출하여 request 스코프에 저장
        String userid = req.getParameter("userid");
        String passwd = req.getParameter("passwd");

        req.setAttribute("userid", userid);
        req.setAttribute("passwd", passwd);

        // (3) login.jsp로 포워딩
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }
}