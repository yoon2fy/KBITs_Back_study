package org.scoula.demoex04;

/* [RequestServlet] 요구사항
○ URL 맵핑 : /request
○ request 스코프에 다음 속성을 설정함
     속성 명 : 속성 값
        ⁃ username: 홍길동
        ⁃ useraddress: 서울
     response.jsp로 포워딩함
 */

// imports
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/request") // ○ URL 맵핑 : /request
public class RequestServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // ○ request 스코프에 다음 속성을 설정
        String username = req.getParameter("username");
        String useraddress = req.getParameter("useraddress");

        req.setAttribute("username", "홍길동");
        req.setAttribute("useraddress","서울");

        //  response.jsp로 포워딩함
        req.getRequestDispatcher("request.jsp").forward(req, resp);
    }
}
