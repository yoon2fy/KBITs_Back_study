package org.scoula.demoex04;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/response_redirect") // ○ URL 맵핑 : /response_redirect
public class ResponseRedirectServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String username = (String) req.getParameter("username");
        String useraddress = (String) req.getParameter("useraddress");

        // ○ request 스코프에 속성을 추출함
        req.setAttribute("username", username);
        req.setAttribute("useraddress", useraddress);

        // ○ redirect_response.jsp 로 포워딩함
        req.getRequestDispatcher("redirect_response.jsp").forward(req, resp);
    }
}
