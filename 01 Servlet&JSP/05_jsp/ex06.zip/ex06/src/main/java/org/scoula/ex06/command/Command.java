package org.scoula.ex06.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface Command {
    public abstract String execute(HttpServletRequest request, HttpServletResponse response)
            throws IOException;
}
// Command = 명령 객체; execute() = 실행을 나타냄.
// 객체의 요청을 캡슐화(execute())하여 서로 다른 요청(create(), update() ...)을 클라이언트가 동일하게 처리할 수 있도록 해주는 디자인 패턴